#include "fifthquestion.h"
#include "ui_fifthquestion.h"
#include "fourthquestion.h"
#include "ui_fourthquestion.h"
#include "thirdquestion.h"
#include "ui_thirdquestion.h"
#include "secondquestion.h"
#include "ui_secondquestion.h"
#include "firstquestion.h"
#include "ui_firstquestion.h"
#include "stylehelper.h"
#include <QLabel>
#include <QPushButton>
#include <QRadioButton>
#include <QPixmap>
#include <QFontDataBase>
#include <QWidget>
#include <QMessageBox>
#include <QTextStream>
#include <qDebug>
#include <scoringmaterials.h>
#include <result.h>

fifthquestion::fifthquestion(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::fifthquestion)
{
    ui->setupUi(this);
    setInterfaceStyleS();
}

fifthquestion::~fifthquestion()
{
    delete ui;
}

void fifthquestion::setInterfaceStyleS() {
    this->setFixedSize(600, 400);
    QPixmap olivandersShop(":/images/olivanderShop.jpg");
    ui->backgroundImage->setPixmap(olivandersShop);

    QLabel *task = new QLabel(this);
    task->setText("Вы столкнулись с магом который имеет более сильные заклинания. Что вы сделаете?:");
    task->setGeometry(30, 110, 300, 240);
    task->setWordWrap(true);

    task->setStyleSheet(StyleHelper::getStartLabelStyle());

    QPushButton *next = new QPushButton(this);
    next->setText("Далее");
    next->setGeometry(405, 310, 120, 40);
    next->setStyleSheet(StyleHelper::getStartButtonsStyle());

    QRadioButton *variant1 = new QRadioButton(this);
    QRadioButton *variant2 = new QRadioButton(this);

    variant1->setText("Разве это ему поможет? Дам\nотпор о котором он и думать\nне мог.");
    variant1->setGeometry(360,110,210,60);
    variant1->setStyleSheet(StyleHelper::getStartRadioBStyle());

    variant2->setText("Использую защитные\nзаклинания и уйду в\nневидимости.");
    variant2->setGeometry(360,175,210,60);
    variant2->setStyleSheet(StyleHelper::getStartRadioBStyle());

    static int unicornhair = 0;
    static int dragonsvein = 0;

    connect(next, &QPushButton::clicked, [=](){
        if (variant1->isChecked() || variant2->isChecked()) {
            if (variant1->isChecked()) {
                dragonsvein += 1;
            }
            if (variant2->isChecked()) {
                unicornhair += 1;
            }
            this->hide();
            ScoringCore(unicornhair, dragonsvein);
            Result RWindow;
            RWindow.move(460, 225);
            RWindow.exec();

        }
        else {
            QMessageBox::information(this, " ", "Выберите один из пунктов.");
        }
    });
}

