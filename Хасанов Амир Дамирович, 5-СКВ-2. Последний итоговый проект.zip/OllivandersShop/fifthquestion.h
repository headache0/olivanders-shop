#ifndef FIFTHQUESTION_H
#define FIFTHQUESTION_H

#include <QDialog>

namespace Ui {
class fifthquestion;
}

class fifthquestion : public QDialog
{
    Q_OBJECT

public:
    explicit fifthquestion(QWidget *parent = nullptr);
    ~fifthquestion();

private:
    Ui::fifthquestion *ui;
    void setInterfaceStyleS();
};

#endif // FIFTHQUESTION_H
