#ifndef FIRSTQUESTION_H
#define FIRSTQUESTION_H
#include <QRadioButton>
#include <QDialog>

namespace Ui {
class firstQuestion;
}

class firstQuestion : public QDialog
{
    Q_OBJECT

public:
    explicit firstQuestion(QWidget *parent = nullptr);
    ~firstQuestion();

private slots:


private:
    Ui::firstQuestion *ui;
    void setInterfaceStyleS();
};

#endif // FIRSTQUESTION_H
