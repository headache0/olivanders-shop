#ifndef FOURTHQUESTION_H
#define FOURTHQUESTION_H

#include <QDialog>

namespace Ui {
class fourthquestion;
}

class fourthquestion : public QDialog
{
    Q_OBJECT

public:
    explicit fourthquestion(QWidget *parent = nullptr);
    ~fourthquestion();

private:
    Ui::fourthquestion *ui;
    void setInterfaceStyleS();
};

#endif // FOURTHQUESTION_H
