#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QFontDataBase>
#include "stylehelper.h"
#include <QWidget>
#include "firstquestion.h"
#include <QPushButton>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    setInterfaceStyle();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::setInterfaceStyle(){
    this->setFixedSize(600, 400);
    QPixmap olivandersShop(":/images/olivanderShop.jpg");
    ui->backgroundImage->setPixmap(olivandersShop);

    QLabel *welcome = new QLabel(this);
    welcome->setText("Добро пожаловать в лавку Олливандера! Для облегчения работы мы создали тест, который поможет вам определивать ваш тип палочки. Когда будете готовы начать, нажмите кнопку \"Начать тест\"");
    welcome->setGeometry(30, 110, 300, 240);
    welcome->setWordWrap(true);

    welcome->setStyleSheet(StyleHelper::getStartLabelStyle());

    QPushButton *startTest = new QPushButton(this);
    startTest->setText("Начать тест");
    startTest->setGeometry(405, 310, 120, 40);

    startTest->setStyleSheet(StyleHelper::getStartButtonsStyle());
    QObject::connect(startTest, SIGNAL(clicked()),this, SLOT(startTestTrue()));
};

void MainWindow::startTestTrue() {
    this->hide();
    firstQuestion FQWindow;
    FQWindow.move(660, 290);
    FQWindow.exec();
    FQWindow.show();
}







