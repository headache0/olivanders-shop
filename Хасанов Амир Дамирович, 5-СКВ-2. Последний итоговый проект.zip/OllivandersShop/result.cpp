#include "result.h"
#include "ui_result.h"
#include "fifthquestion.h"
#include "ui_fifthquestion.h"
#include "fourthquestion.h"
#include "ui_fourthquestion.h"
#include "thirdquestion.h"
#include "ui_thirdquestion.h"
#include "secondquestion.h"
#include "ui_secondquestion.h"
#include "firstquestion.h"
#include "ui_firstquestion.h"
#include "stylehelper.h"
#include <QLabel>
#include <QPushButton>
#include <QRadioButton>
#include <QPixmap>
#include <QFontDataBase>
#include <QWidget>
#include <QMessageBox>
#include <QTextStream>
#include <qDebug>
#include <scoringmaterials.h>
#include <result.h>

Result::Result(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Result)
{
    ui->setupUi(this);
    setInterfaceStyleS();
}

Result::~Result()
{
    delete ui;
}

void Result::setInterfaceStyleS(){
    this->setFixedSize(1000, 530);
    QPixmap TakeBranch(":/images/TAKE_BRANCH.png");
    ui->backgroundImage->setPixmap(TakeBranch);

    QLabel *youTaken = new QLabel(this);
    youTaken->setStyleSheet(StyleHelper::getStartLabelStyleWithoutPX());
    youTaken->setGeometry(300, 20, 400, 60);
    youTaken->setText("      Вы получили");

    static int lipa;
    static int klen;
    static int eben;
    static int dragonsvain;
    static int unicornhair;

    QLabel *branch_1 = new QLabel(this);
    QLabel *branch_2 = new QLabel(this);

    QLabel *description1 = new QLabel(this);
    QLabel *description2 = new QLabel(this);

    QPixmap BranchLU(":/images/lipa-unicorn.png");
    QPixmap BranchLD(":/images/lipa-dragons.png");
    QPixmap BranchKU(":/images/klen-unicorn.png");
    QPixmap BranchKD(":/images/klen-dragons.png");
    QPixmap BranchEU(":/images/eben-unicorn.png");
    QPixmap BranchED(":/images/eden-dragons.png");

    getDatas(lipa, klen, eben, dragonsvain, unicornhair);

    if (lipa > klen && lipa > eben && dragonsvain > unicornhair) {
        branch_1->setPixmap(BranchLD);
        branch_1->setGeometry(50,90,BranchLD.width(),BranchLD.height());
        description1->setGeometry(600,90,350,BranchLD.height());
        description1->setText("Эта необычная и очень интересная древесина была очень популярна в девятнадцатом веке. Считается, что такие палочки отлично подходят провидцам и одарённым легилиментам.\n\nКак правило, сердечная жила дракона в результате дает палочки с наибольшей силой, которые способны на самые яркие заклинания.");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }
    if (lipa > klen && lipa > eben && unicornhair > dragonsvain) {
        branch_1->setPixmap(BranchLU);
        branch_1->setGeometry(50,90,BranchLD.width(),BranchLD.height());
        description1->setGeometry(600,90,350,BranchLD.height());
        description1->setText("Эта необычная и очень интересная древесина была очень популярна в девятнадцатом веке. Считается, что такие палочки отлично подходят провидцам и одарённым легилиментам.\n\nВолос единорога дает самую стойкую магию и меньше других подвергается влиянию колебаний и блокировок.");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }
    if (klen > lipa && klen > eben && dragonsvain > unicornhair) {
        branch_1->setPixmap(BranchKD);
        branch_1->setGeometry(50,90,BranchLD.width(),BranchLD.height());
        description1->setGeometry(600,90,350,BranchLD.height());
        description1->setText("Владельцами кленовых палочек очень часто оказываются путешественники и исследователи. Такие палочки не любят домоседов и им нужны амбициозные волшебники, иначе их магия становится скучной и тусклой.\n\nКак правило, сердечная жила дракона в результате дает палочки с наибольшей силой, которые способны на самые яркие заклинания.");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }
    if (klen > lipa && klen > eben && unicornhair > dragonsvain) {
        branch_1->setPixmap(BranchKU);
        branch_1->setGeometry(50,90,BranchLD.width(),BranchLD.height());
        description1->setGeometry(600,90,350,BranchLD.height());
        description1->setText("Владельцами кленовых палочек очень часто оказываются путешественники и исследователи. Такие палочки не любят домоседов и им нужны амбициозные волшебники, иначе их магия становится скучной и тусклой.\n\nВолос единорога дает самую стойкую магию и меньше других подвергается влиянию колебаний и блокировок.");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }
    if (eben > lipa && eben > klen && dragonsvain > unicornhair) {
        branch_1->setPixmap(BranchED);
        branch_1->setGeometry(50,90,BranchLD.width(),BranchLD.height());
        description1->setGeometry(600,90,350,BranchLD.height());
        description1->setText("Это угольно-чёрное дерево обладает впечатляющей наружностью и репутацией, поскольку отлично подходит для всех видов боевой магии и трансфигурации. Лучше всего такая палочка чувствует себя в руках людей, не боящихся быть самими собой. \n\nКак правило, сердечная жила дракона в результате дает палочки с наибольшей силой, которые способны на самые яркие заклинания.");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }
    if (eben > lipa && eben > klen && unicornhair > dragonsvain) {
        branch_1->setPixmap(BranchEU);
        branch_1->setGeometry(50,90,BranchLD.width(),BranchLD.height());
        description1->setGeometry(600,90,350,BranchLD.height());
        description1->setText("Это угольно-чёрное дерево обладает впечатляющей наружностью и репутацией, поскольку отлично подходит для всех видов боевой магии и трансфигурации. Лучше всего такая палочка чувствует себя в руках людей, не боящихся быть самими собой. \n\nВолос единорога дает самую стойкую магию и меньше других подвергается влиянию колебаний и блокировок.");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }
    if (lipa == klen && lipa > eben && dragonsvain > unicornhair) {
        branch_1->setPixmap(BranchLD);
        branch_2->setPixmap(BranchKD);
        branch_1->setGeometry(50,90,BranchLD.width(),BranchLD.height());
        branch_2->setGeometry(60+BranchLD.width(), 90, BranchKD.width(), BranchKD.height());
        description1->setGeometry(600,90,350,BranchLD.height());
        description1->setText("Попробуйте обе эти палочки, одна из них точно вам подойдет! Выбирайте первую, если чувствуете что в вас присутствует дар провидца. Выбирайте вторую, если любите приключения!\n\nВ ЛЮБОМ СЛУЧАЕ СОВЕТУЕМ ПРОКОНСУЛЬТИРОВАТЬСЯ С ОЛЛИВАНДЕРОМ!");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }
    if (lipa == klen && lipa > eben && unicornhair > dragonsvain) {
        branch_1->setPixmap(BranchLU);
        branch_2->setPixmap(BranchKU);
        branch_1->setGeometry(50,90,BranchLU.width(),BranchLU.height());
        branch_2->setGeometry(60+BranchLU.width(), 90, BranchKU.width(), BranchKU.height());
        description1->setGeometry(600,90,350,BranchLU.height());
        description1->setText("Попробуйте обе эти палочки, одна из них точно вам подойдет! Выбирайте первую, если чувствуете что в вас присутствует дар провидца. Выбирайте вторую, если любите приключения!\n\nВ ЛЮБОМ СЛУЧАЕ СОВЕТУЕМ ПРОКОНСУЛЬТИРОВАТЬСЯ С ОЛЛИВАНДЕРОМ!");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }
    if (eben == klen && eben > lipa && dragonsvain > unicornhair) {
        branch_1->setPixmap(BranchED);
        branch_2->setPixmap(BranchKD);
        branch_1->setGeometry(50,90,BranchED.width(),BranchED.height());
        branch_2->setGeometry(60+BranchED.width(), 90, BranchKD.width(), BranchKD.height());
        description1->setGeometry(600,90,350,BranchED.height());
        description1->setText("Попробуйте обе эти палочки, одна из них точно вам подойдет! Выбирайте первую, если вы решительны и целеустремленны больше чем кто бы то ни было другой. Выбирайте вторую, если любите приключения!\n\nВ ЛЮБОМ СЛУЧАЕ СОВЕТУЕМ ПРОКОНСУЛЬТИРОВАТЬСЯ С ОЛЛИВАНДЕРОМ!");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }
    if (eben == klen && eben > lipa && unicornhair > dragonsvain) {
        branch_1->setPixmap(BranchEU);
        branch_2->setPixmap(BranchKU);
        branch_1->setGeometry(50,90,BranchEU.width(),BranchEU.height());
        branch_2->setGeometry(60+BranchEU.width(), 90, BranchKU.width(), BranchKU.height());
        description1->setGeometry(600,90,350,BranchEU.height());
        description1->setText("Попробуйте обе эти палочки, одна из них точно вам подойдет! Выбирайте первую, если вы решительны и целеустремленны больше чем кто бы то ни было другой. Выбирайте вторую, если любите приключения!\n\nВ ЛЮБОМ СЛУЧАЕ СОВЕТУЕМ ПРОКОНСУЛЬТИРОВАТЬСЯ С ОЛЛИВАНДЕРОМ!");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }
    if (eben == lipa && eben > klen && dragonsvain > unicornhair) {
        branch_1->setPixmap(BranchED);
        branch_2->setPixmap(BranchLD);
        branch_1->setGeometry(50,90,BranchED.width(),BranchED.height());
        branch_2->setGeometry(60+BranchED.width(), 90, BranchLD.width(), BranchLD.height());
        description1->setGeometry(600,90,350,BranchLD.height());
        description1->setText("Попробуйте обе эти палочки, одна из них точно вам подойдет! Выбирайте первую, если вы решительны и целеустремленны больше чем кто бы то ни было другой. Выбирайте вторую, если чувствуете что в вас присутствует дар провидца.\n\nВ ЛЮБОМ СЛУЧАЕ СОВЕТУЕМ ПРОКОНСУЛЬТИРОВАТЬСЯ С ОЛЛИВАНДЕРОМ!");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }
    if (eben == lipa && eben > klen && unicornhair > dragonsvain) {
        branch_1->setPixmap(BranchEU);
        branch_2->setPixmap(BranchLU);
        branch_1->setGeometry(50,90,BranchEU.width(),BranchEU.height());
        branch_2->setGeometry(60+BranchEU.width(), 90, BranchLU.width(), BranchLU.height());
        description1->setGeometry(600,90,350,BranchLU.height());
        description1->setText("Попробуйте обе эти палочки, одна из них точно вам подойдет! Выбирайте первую, если вы решительны и целеустремленны больше чем кто бы то ни было другой. Выбирайте вторую, если чувствуете что в вас присутствует дар провидца.\n\nВ ЛЮБОМ СЛУЧАЕ СОВЕТУЕМ ПРОКОНСУЛЬТИРОВАТЬСЯ С ОЛЛИВАНДЕРОМ!");
        description1->setStyleSheet(StyleHelper::getStartLabelStyle());
        description1->setWordWrap(true);
    }

}
