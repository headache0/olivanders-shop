#include "scoringmaterials.h"
#include <qDebug>

int finalLipa = 0;
int finalKlen = 0;
int finalEben = 0;

int dragonsvein;
int unicornhair;

void ScoringMaterial(int &lipa, int &klen, int &eben) {
    finalKlen += klen;
    finalLipa += lipa;
    finalEben += eben;
}
void ScoringCore(int &UnicornHair, int &DragonsVein){
    dragonsvein += DragonsVein;
    unicornhair += UnicornHair;
}

void getDatas(int &lipa, int &klen, int &eben, int &dragonSvein, int &unicornHair) {
    lipa = finalLipa;
    klen = finalKlen;
    eben = finalEben;

    dragonSvein = dragonsvein;
    unicornHair = unicornhair;
}
