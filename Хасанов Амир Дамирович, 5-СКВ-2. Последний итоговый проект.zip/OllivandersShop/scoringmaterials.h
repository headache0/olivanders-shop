#ifndef SCORINGMATERIALS_H
#define SCORINGMATERIALS_H


class ScoringMaterials
{
public:

};
void ScoringMaterial(int &lipa, int &klen, int &eben);
void ScoringCore(int &UnicornHair, int &DragonsVein);
void getDatas(int &lipa, int &klen, int &eben, int &dragonSvein, int &unicornHair);

#endif // SCORINGMATERIALS_H
