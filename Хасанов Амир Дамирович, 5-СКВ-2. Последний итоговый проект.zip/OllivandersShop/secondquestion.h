#ifndef SECONDQUESTION_H
#define SECONDQUESTION_H

#include <QDialog>

namespace Ui {
class secondquestion;
}

class secondquestion : public QDialog
{
    Q_OBJECT

public:
    explicit secondquestion(QWidget *parent = nullptr);
    ~secondquestion();

private:
    Ui::secondquestion *ui;
    void setInterfaceStyleS();
};

#endif // SECONDQUESTION_H
