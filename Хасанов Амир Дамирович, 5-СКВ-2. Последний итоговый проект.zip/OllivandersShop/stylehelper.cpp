#include "stylehelper.h"

QString StyleHelper::getStartButtonsStyle() {
    return "QPushButton{"
           "    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(22, 22, 22, 233), stop:1 rgba(2, 2, 2, 255));"
           "    selection-background-color: rgb(31, 31, 31);"
           "    color: rgb(255, 255, 255);"
           "    border: none;"
           "    border-radius: 15;"
           "    font-family: Bitter ExtraBold;"
           "    font-size:16px;"
           "}"
           "QPushButton::hover{"
           "    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(16, 16, 16, 233), stop:1 rgba(2, 2, 2, 255));"
           "    color: rgb(176, 176, 176);"
           "}"
           "QPushButton::pressed{"
           "    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(7, 7, 7, 233), stop:1 rgba(0, 0, 0, 255));"
           "    color: rgb(110, 110, 110);"
           "}";
}

QString StyleHelper::getStartLabelStyle() {
    return "QLabel{"
           "    color: qlineargradient(spread:pad, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(115, 115, 115, 255), stop:1 rgba(255, 255, 255, 255));"
           "    padding: 10px;"
           "    border: none;"
           "    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(34, 34, 34, 233), stop:1 rgba(9, 9, 9, 255));"
           "    border-radius: 25px;"
           "    font-family: Bitter ExtraBold;"
           "    font-size:20px;"
           "}";
}

QString StyleHelper::getStartRadioBStyle() {
    return "QRadioButton{"
           "   color: rgb(255, 255, 255);"
           "   padding: 5px;"
           "   border: none;"
           "   background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(34, 34, 34, 233), stop:1 rgba(9, 9, 9, 255));"
           "   border-radius:10px;"
           "   font-family: Bitter ExtraBold;"
           "}";
}

QString StyleHelper::getStartLabelStyleWithoutPX() {
    return "QLabel{"
           "    color: qlineargradient(spread:pad, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(115, 115, 115, 255), stop:1 rgba(255, 255, 255, 255));"
           "    padding: 10px;"
           "    border: none;"
           "    background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:0, y2:1, stop:0 rgba(22, 22, 22, 233), stop:1 rgba(2, 2, 2, 255));"
           "    border-radius: 25px;"
           "    font-family: Bitter ExtraBold;"
           "    font-size:40px;"
           "}";

}
