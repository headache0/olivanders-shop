#ifndef STYLEHELPER_H
#define STYLEHELPER_H
#include <QString>


class StyleHelper
{
public:
    static QString getStartButtonsStyle();
    static QString getStartLabelStyle();
    static QString getStartRadioBStyle();
    static QString getStartLabelStyleWithoutPX();
};

#endif // STYLEHELPER_H
