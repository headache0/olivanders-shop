#include "thirdquestion.h"
#include "ui_thirdquestion.h"
#include "secondquestion.h"
#include "ui_secondquestion.h"
#include "firstquestion.h"
#include "ui_firstquestion.h"
#include "stylehelper.h"
#include <QLabel>
#include <QPushButton>
#include <QRadioButton>
#include <QPixmap>
#include <QFontDataBase>
#include <QWidget>
#include <QMessageBox>
#include <QTextStream>
#include <qDebug>
#include "fourthquestion.h"
#include "scoringmaterials.h"

thirdquestion::thirdquestion(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::thirdquestion)
{
    ui->setupUi(this);
    setInterfaceStyleS();
}

thirdquestion::~thirdquestion()
{
    delete ui;
}

void thirdquestion::setInterfaceStyleS() {
    this->setFixedSize(600, 400);
    QPixmap olivandersShop(":/images/olivanderShop.jpg");
    ui->backgroundImage->setPixmap(olivandersShop);

    QLabel *task = new QLabel(this);
    task->setText("Во время путешествия по джунглям вы обнаруживаете древний храм.\nЕсть 3 варианта действий:");
    task->setGeometry(30, 110, 300, 240);
    task->setWordWrap(true);

    task->setStyleSheet(StyleHelper::getStartLabelStyle());

    QPushButton *next = new QPushButton(this);
    next->setText("Далее");
    next->setGeometry(405, 310, 120, 40);
    next->setStyleSheet(StyleHelper::getStartButtonsStyle());

    QRadioButton *variant1 = new QRadioButton(this);
    QRadioButton *variant2 = new QRadioButton(this);
    QRadioButton *variant3 = new QRadioButton(this);

    variant1->setText("Исследовать храм");
    variant1->setGeometry(360,110,210,60);
    variant1->setStyleSheet(StyleHelper::getStartRadioBStyle());

    variant2->setText("Пройти мимо и следовать\nплану путешествия.");
    variant2->setGeometry(360,175,210,60);
    variant2->setStyleSheet(StyleHelper::getStartRadioBStyle());

    variant3->setText("Вы внимательно слушаете\nсвои мысли,и принимаете\nрешение продолжить путь.");
    variant3->setGeometry(360,240,210,60);
    variant3->setStyleSheet(StyleHelper::getStartRadioBStyle());

    static int klen = 0;
    static int lipa = 0;
    static int eben = 0;


    connect(next, &QPushButton::clicked, [=](){
        if (variant1->isChecked() || variant2->isChecked() || variant3->isChecked()) {
            if (variant1->isChecked()) {
                klen += 1;
            }
            if (variant2->isChecked()) {
                eben += 1;
            }
            if (variant3->isChecked()) {
                lipa += 1;
            }
            ScoringMaterial(lipa, klen, eben);
            this->hide();
            fourthquestion FQWindow;
            FQWindow.move(660, 290);
            FQWindow.exec();




        }
        else {
            QMessageBox::information(this, " ", "Выберите один из пунктов.");
        }
    });
}
