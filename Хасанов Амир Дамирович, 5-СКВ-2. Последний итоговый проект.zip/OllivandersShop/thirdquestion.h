#ifndef THIRDQUESTION_H
#define THIRDQUESTION_H

#include <QDialog>

namespace Ui {
class thirdquestion;
}

class thirdquestion : public QDialog
{
    Q_OBJECT

public:
    explicit thirdquestion(QWidget *parent = nullptr);
    ~thirdquestion();

private:
    Ui::thirdquestion *ui;
    void setInterfaceStyleS();
};

#endif // THIRDQUESTION_H
